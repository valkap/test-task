<?
CModule::AddAutoloadClasses(
    'valkap.parser',
    array(
        'ValkapParser' => 'classes/general/parser.php',
    )
);
?>
