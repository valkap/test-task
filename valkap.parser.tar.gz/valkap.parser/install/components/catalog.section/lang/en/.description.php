<?
$MESS ['T_IBLOCK_DESC_CATALOG'] = "Catalog";
$MESS ['IBLOCK_SECTION_TEMPLATE_NAME'] = "Section elements";
$MESS ['IBLOCK_SECTION_TEMPLATE_DESCRIPTION'] = "Displays the section elements with a set of properties, prices etc.";
?>