<?
$MESS["IBLOCK_MODULE_NOT_INSTALLED"] = "Модуль \"Информационные блоки\" не установлен";
$MESS["CATALOG_SECTION_NOT_FOUND"] = "Раздел не найден";
?>