<?
$MESS ['T_IBLOCK_DESC_CATALOG'] = "Каталог";
$MESS ['IBLOCK_SECTION_TEMPLATE_NAME'] = "Элементы раздела";
$MESS ['IBLOCK_SECTION_TEMPLATE_DESCRIPTION'] = "Выводит элементы раздела с указанным набором свойств, цен и т.д.";
?>