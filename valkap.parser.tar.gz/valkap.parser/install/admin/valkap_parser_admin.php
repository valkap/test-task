<?
require_once($_SERVER["DOCUMENT_ROOT"]."/bitrix/modules/valkap.parser/admin/valkap_parser_admin.php");
?>