<?
$MESS ['VALKAP_PARSER_PAGE_TITLE'] = "Парсер CSV файлов";
$MESS ['VALKAP_PARSER_IMP_DATA_FILE'] = "Файл данных:";
$MESS ['VALKAP_PARSER_IMP_OPEN'] = "Открыть";
$MESS ['VALKAP_PARSER_IMP_INFOBLOCK'] = "Информационный блок:";
$MESS["VALKAP_PARSER_IMP_NOT_CSV"] = "Загружаемый файл на является CSV файлом";
$MESS["VALKAP_PARSER_FIRST_HEADER"] = "Первая строка содержит названия полей";
$MESS["VALKAP_PARSER_ERROR_UPDATE"] = "Ошибка добавления (обновления) товара";
?>
