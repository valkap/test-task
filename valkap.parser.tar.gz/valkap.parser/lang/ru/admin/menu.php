<?
$MESS ['VALKAP_PARSER_MENU_MAIN'] = "Парсер CSV файлов";
$MESS ['VALKAP_PARSER_MENU_MAIN_TITLE'] = "Парсер CSV файлов";

$MESS ['VALKAP_PARSER_MENU_EVENTS'] = "Парсер CSV файлов";
$MESS ['VALKAP_PARSER_MENU_EVENTS_TITLE'] = "Парсер CSV файлов";
?>
