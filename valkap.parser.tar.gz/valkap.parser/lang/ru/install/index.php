<?
$MESS["valkap.parser_MODULE_NAME"] = "Парсер контента";
$MESS["valkap.parser_MODULE_DESC"] = "";
$MESS["valkap.parser_PARTNER_NAME"] = "ValKap";
$MESS["valkap.parser_PARTNER_URI"] = "http://rozumniki.ua";
$MESS["VALKAP_IB_PARSER"] = "Контент из CSV файла";
$MESS["VALKAP_IB_VENDOR"] = "Поставщик";
$MESS["VALKAP_IB_MATERIAL"] = "Материал";
?>